AveDesktopEffects
(c) Andreas Verhoeven, 2007 (andreasverhoeven@hotmail.com)

INSTALLATION

0) Make sure you have http://www.microsoft.com/downloads/details.aspx?familyid=200b2fd9-ae1a-4a14-984d-389c36f85647&displaylang=en installed

1) call regsvr32 on each DLL yourself in admin mode

USE

1) Right click an empty space on your desktop
2) Click on 'Configure Desktop Effects' in the menu
3) Select an effect in the menu
4) Hit Start

DO NOT DISTRIBUTE THESE FILES!